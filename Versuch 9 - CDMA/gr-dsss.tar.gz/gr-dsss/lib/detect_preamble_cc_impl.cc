/* -*- c++ -*- */
/* 
 * Copyright 2013 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "detect_preamble_cc_impl.h"

namespace gr {
  namespace dsss {

    detect_preamble_cc::sptr
    detect_preamble_cc::make(unsigned int payload_length, float threshold, unsigned int automatic)
    {
      return gnuradio::get_initial_sptr
        (new detect_preamble_cc_impl(payload_length, threshold, automatic));
    }

    /*
     * The private constructor
     */
    detect_preamble_cc_impl::detect_preamble_cc_impl(unsigned int payload_length, float threshold, unsigned int automatic)
      : gr::block("detect_preamble_cc",
              gr::io_signature::make(1, 1, sizeof(gr_complex)),
              gr::io_signature::make(4, 4, sizeof(gr_complex))),
	      d_payload_len(payload_length), d_threshold(threshold), d_automatic(automatic), d_frame_len(payload_length+32)
    {
        set_output_multiple(d_payload_len);
    }

    /*
     * Our virtual destructor.
     */
    detect_preamble_cc_impl::~detect_preamble_cc_impl()
    {
    }

    void
    detect_preamble_cc_impl::forecast (int noutput_items, gr_vector_int &ninput_items_required)
    {
        ninput_items_required[0] = noutput_items*d_frame_len/d_payload_len;
    }

    int
    detect_preamble_cc_impl::general_work (int noutput_items,
                       gr_vector_int &ninput_items,
                       gr_vector_const_void_star &input_items,
                       gr_vector_void_star &output_items)
    {
        const gr_complex *in = (const gr_complex *) input_items[0];
	gr_complex *out1 = (gr_complex *) output_items[0];
        gr_complex *out2 = (gr_complex *) output_items[1];
        gr_complex *out3 = (gr_complex *) output_items[2];
        gr_complex *out4 = (gr_complex *) output_items[3];

	// Initialisation of the preamble
        float d_preamble[32] = {1,1,-1,-1,-1,-1,1,-1,-1,1,-1,-1,-1,-1,-1,-1,1,1,1,-1,1,-1,-1,1,-1,1,1,-1,-1,1,-1,0};

	gr_complex d_preamble_c[32];

        for(int i = 0; i < 32; i++) {
            d_preamble_c[i] = gr_complex(d_preamble[i], 0);
        }

        gr_complex corr[160];
        gr_complex corr_phase_offset;
        
        gr_complex freq_cor[160];
        gr_complex in_freq_cor[160];
        
        gr_complex phase_cor;
        
        float f_est = 0.0;
        
        float max = 0.0;
        float max_test = 0.0;
        unsigned int max_index = 0;
        
        unsigned int n_frames = 0;
    
        // Incrementing i by 1 means going one frame forward, at the output one payload length forward
        for(int i = 0; i < noutput_items/d_payload_len-1; i++) {
            
            // Correlate the input stream stepwise with the preamble
            for(int n = 0; n < d_frame_len; n++) {

                corr[n] = gr_complex(0.0,0.0);
               
                for(int j = 0; j < 32; j++) {   
                    corr[n] += in[i*d_frame_len+n+j]*d_preamble_c[j];
                }
            } 
                
            // Search the maximum of the correlation in a vector of length d_frame_len=32+d_payload_len
            max = abs(corr[0]);
            
            for(int n = 1; n < d_frame_len; n++) {
            
                max_test = abs(corr[n]);
                
                if( max_test > max) {
                    max = max_test;
                    max_index = n;
                }
            }
                
            // Estimate and correct the frequency offset
            freq_cor[0] = gr_complex(0.0,0.0);

            for(int k = 0; k < 15; k++) {
                freq_cor[0] += conj(in[i*d_frame_len+max_index+k+15]*d_preamble_c[k+15])*in[i*d_frame_len+max_index+k]*d_preamble_c[k];//*gr_complex(0.06666666667,0.0);
            }

            f_est = arg(freq_cor[0])*(-0.01061032954);
            

            in_freq_cor[0] = in[i*d_frame_len+max_index];


            for(int k = 1; k < d_frame_len; k++) {
                in_freq_cor[k] = in[i*d_frame_len+max_index+k]*gr_complex(cos(-6.28318530718*f_est*k),sin(-6.28318530718*f_est*k));
            }
                
            // Estimate the remaining phase offset
            corr_phase_offset = gr_complex(0.0,0.0);
                
            for(int k = 0; k < 31; k++) {   
                corr_phase_offset += in_freq_cor[k]*d_preamble_c[k];
            }

            phase_cor = conj(corr_phase_offset)/abs(corr_phase_offset);  

            // Automatic Modus
            if(d_automatic == 1) {                   
                // Output the corrected payload data and estimated parameters
                for(int n = 0; n < d_payload_len; n++) {
                    out1[i*d_payload_len+n] = in_freq_cor[n+32]*phase_cor;
                    out2[i*d_payload_len+n] = corr_phase_offset;
                    out3[i*d_payload_len+n] = gr_complex(f_est,0.0);
                    out4[i*d_payload_len+n] = gr_complex(max_index,0.0);
                }

		// Increase the number of produced payload_frames   
                n_frames++;
	    }
	    else {
	        // If the absolut value of the correlation peak is higher than the threshold, output the payload data, corrected by the sign of the correlation peak
                if(abs(corr_phase_offset) >= d_threshold) {
		    // Output the corrected payload data and estimated parameters
                    for(int n = 0; n < d_payload_len; n++) {
                        out1[i*d_payload_len+n] = in_freq_cor[n+32]*phase_cor;
                        out2[i*d_payload_len+n] = corr_phase_offset;
                        out3[i*d_payload_len+n] = gr_complex(f_est,0.0);
                    	out4[i*d_payload_len+n] = gr_complex(max_index,0.0);
		    }

		    // Increase the number of produced payload_frames   
                    n_frames++;
	        }
            }
            
        }

        // Tell runtime system how many input items we consumed on
        // each input stream.
//        consume_each (noutput_items*d_frame_len/d_payload_len);
        consume_each (max_index+n_frames*d_frame_len);
        // Tell runtime system how many output items we produced.
        return n_frames*d_payload_len;
    }

  } /* namespace dsss */
} /* namespace gr */


/* -*- c++ -*- */
/* 
 * Copyright 2014 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "correlation_seq1_cc_impl.h"

namespace gr {
  namespace dsss {

    correlation_seq1_cc::sptr
    correlation_seq1_cc::make(unsigned int pn_length, unsigned int interpolation)
    {
      return gnuradio::get_initial_sptr
        (new correlation_seq1_cc_impl(pn_length, interpolation));
    }

    /*
     * The private constructor
     */
    correlation_seq1_cc_impl::correlation_seq1_cc_impl(unsigned int pn_length, unsigned int interpolation)
      : gr::block("correlation_seq1_cc",
              gr::io_signature::make(1, 1, sizeof(gr_complex)),
              gr::io_signature::make(1, 1, sizeof(gr_complex))),
	      d_pn_length(pn_length), d_interpolation(interpolation)
    {
        set_output_multiple(d_pn_length*d_interpolation);
    }

    /*
     * Our virtual destructor.
     */
    correlation_seq1_cc_impl::~correlation_seq1_cc_impl()
    {
    }

    void
    correlation_seq1_cc_impl::forecast (int noutput_items, gr_vector_int &ninput_items_required)
    {
        /* <+forecast+> e.g. ninput_items_required[0] = noutput_items */
    }

    int
    correlation_seq1_cc_impl::general_work (int noutput_items,
                       gr_vector_int &ninput_items,
                       gr_vector_const_void_star &input_items,
                       gr_vector_void_star &output_items)
    {
        const gr_complex *in = (const gr_complex *) input_items[0];
        gr_complex *out = (gr_complex *) output_items[0];

//	float s_mseq3[3] = {-1,1,-1};	
//	float s_mseq7[7] = {-1,1,1,-1,-1,-1,1};
//	float s_mseq15[15] = {-1,1,1,1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1};
//	float s_mseq31[31] = {-1,1,-1,1,-1,-1,-1,1,-1,-1,1,1,1,-1,-1,-1,-1,-1,1,1,-1,-1,1,-1,1,1,-1,1,1,1,1};
        float s_goldseq31_1[31] = {1,1,-1,-1,-1,-1,1,-1,-1,1,-1,-1,-1,-1,-1,-1,1,1,1,-1,1,-1,-1,1,-1,1,1,-1,-1,1,-1};
        
	gr_complex s_goldseq31_c[31];

        for(int i = 0; i < 31; i++) {
            s_goldseq31_c[i] = gr_complex(s_goldseq31_1[i],0.0);
        }        
        
        
        // Correlate the incoming data with the reference gold sequence
        for(int i = 0; i < noutput_items-d_pn_length*d_interpolation; i += d_interpolation) {
            
            for(int k = 0; k < d_interpolation; k++) {
                out[i+k] = 0;
            
                for(int j = 0; j < d_pn_length; j++) {
                    out[i+k] += in[k+i+j*d_interpolation]*s_goldseq31_c[j];
                }
            }

/*            
            if(pn_length == 3) {
                for(int j = 0; j < pn_length; j++) {
                    out[i] += in[i+j]*s_mseq3[j];
                }
            }
            else if(pn_length == 7) {
                for(int j = 0; j < pn_length; j++) {
                    out[i] += in[i+j]*s_mseq7[j];
                }
            }
            else if(pn_length == 15) {
                for(int j = 0; j < pn_length; j++) {
                    out[i] += in[i+j]*s_mseq15[j];
                }
            }
            else {
                for(int j = 0; j < pn_length; j++) {
                    out[i] += in[i+j]*s_goldseq31[j];
                }
            }
*/            
        }

        // Tell runtime system how many input items we consumed on
        // each input stream.
        consume_each (noutput_items-d_pn_length*d_interpolation);

        // Tell runtime system how many output items we produced.
        return noutput_items-d_pn_length*d_interpolation;
    }

  } /* namespace dsss */
} /* namespace gr */


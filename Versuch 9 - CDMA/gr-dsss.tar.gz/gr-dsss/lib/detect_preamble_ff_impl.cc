/* -*- c++ -*- */
/* 
 * Copyright 2013 <+YOU OR YOUR COMPANY+>.
 * 
 * This is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3, or (at your option)
 * any later version.
 * 
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 51 Franklin Street,
 * Boston, MA 02110-1301, USA.
 */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include <gnuradio/io_signature.h>
#include "detect_preamble_ff_impl.h"

namespace gr {
  namespace dsss {

    detect_preamble_ff::sptr
    detect_preamble_ff::make(unsigned int payload_length, float threshold, unsigned int automatic)
    {
      return gnuradio::get_initial_sptr
        (new detect_preamble_ff_impl(payload_length, threshold, automatic));
    }

    /*
     * The private constructor
     */
    detect_preamble_ff_impl::detect_preamble_ff_impl(unsigned int payload_length, float threshold, unsigned int automatic)
      : gr::block("detect_preamble_ff",
              gr::io_signature::make(1, 1, sizeof(float)),
              gr::io_signature::make(2, 2, sizeof(float))),
	      d_payload_len(payload_length), d_threshold(threshold), d_automatic(automatic), d_frame_len(payload_length+31)
    {
        set_output_multiple(d_payload_len);
        set_history(d_frame_len+1);
    }

    /*
     * Our virtual destructor.
     */
    detect_preamble_ff_impl::~detect_preamble_ff_impl()
    {
    }

    void
    detect_preamble_ff_impl::forecast (int noutput_items, gr_vector_int &ninput_items_required)
    {
        ninput_items_required[0] = noutput_items*d_frame_len/d_payload_len;
    }

    int
    detect_preamble_ff_impl::general_work (int noutput_items,
                       gr_vector_int &ninput_items,
                       gr_vector_const_void_star &input_items,
                       gr_vector_void_star &output_items)
    {
        const float *in = (const float *) input_items[0];
        float *out1 = (float *) output_items[0];
        float *out2 = (float *) output_items[1];

	float d_preamble[32] = {1,1,-1,-1,-1,-1,1,-1,-1,1,-1,-1,-1,-1,-1,-1,1,1,1,-1,1,-1,-1,1,-1,1,1,-1,-1,1,-1,0};
        
        float corr[160];
        unsigned int n_frames = 0;
        
        float max = 0.0;
        float max_test = 0.0;
        unsigned int max_index = 0;
        
        // Automatic Modus
        if(d_automatic == 1) {
            // Incrementing i by 1 means going one frame forward, at the output one payload length forward
            for(int i = 0; i < noutput_items/d_payload_len; i++) {
                
                // Correlate the input stream stepwise with the preamble
                for(int n = 0; n < d_frame_len; n++) {

                    corr[n] = 0.0;
               
                    for(int j = 0; j < 32; j++) {   
                        corr[n] += in[i*d_frame_len+n+j]*d_preamble[j];
                    }
                } 
                
                // Search the maximum of the correlation in a vector of length d_frame_len=32+d_payload_len
                max = abs(corr[0]);
                
                for(int n = 1; n < d_frame_len; n++) {
            
                    max_test = fabs(corr[n]);
                
                    if( max_test > max) {
                        max = max_test;
                        max_index = n;
                    }
                }
                
                
                // Output the payload data and maximum
                for(int n = 0; n < d_payload_len; n++) {
                    out1[i*d_payload_len+n] = in[i*d_frame_len+max_index+32+n];
                    out2[i*d_payload_len+n] = max;
                }
                
                n_frames++;
            
            }        
        }
        
        // Individual Threshold
        else {        
            for(int i = 0; i < noutput_items*d_frame_len/d_payload_len; i++) {
        
                // Correlate the input stream with the preamble
                corr[0] = 0.0;
                   
                for(int j = 0; j < 31; j++) {   
                    corr[0] += in[i+j]*d_preamble[j];
                }
                
                // If the absolut value of the correlation peak is higher than the threshold, output the payload data, corrected by the sign of the correlation peak
                if(fabs(corr[0]) >= d_threshold) {
                
                    for(int k = 0; k < d_payload_len; k++) {
                        out1[n_frames*d_payload_len+k] = in[i+k+32]*corr[0];
                        out2[n_frames*d_payload_len+k] = corr[0];
                    }
                
                    // Increase the number of produced payload_frames   
                    n_frames++;
                }
            }
      
        }
        
        // Tell runtime system how many input items we consumed on
        // each input stream.
        consume_each (noutput_items*d_frame_len/d_payload_len);

        // Tell runtime system how many output items we produced.
        return n_frames*d_payload_len;
    }

  } /* namespace dsss */
} /* namespace gr */

